<?php 
require_once 'includes/config.php';

if (!isset($_GET['id'])) {
    redirect('index.php');
}

$animeId = $_GET['id'];
$isFavorite = false;

// Отримання інформації про аніме
$stmt = $pdo->prepare("SELECT * FROM anime WHERE id = ?");
$stmt->execute([$animeId]);
$anime = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$anime) {
    redirect('index.php');
}

// Перевірка чи аніме в улюблених
if (isLoggedIn()) {
    $stmt = $pdo->prepare("SELECT 1 FROM user_favorites WHERE user_id = ? AND anime_id = ?");
    $stmt->execute([$_SESSION['user_id'], $animeId]);
    $isFavorite = $stmt->fetch();
}

// Обробка додавання/видалення з улюблених
if (isLoggedIn() && isset($_POST['toggle_favorite'])) {
    if ($isFavorite) {
        $stmt = $pdo->prepare("DELETE FROM user_favorites WHERE user_id = ? AND anime_id = ?");
        $stmt->execute([$_SESSION['user_id'], $animeId]);
        $isFavorite = false;
    } else {
        $stmt = $pdo->prepare("INSERT INTO user_favorites (user_id, anime_id) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $animeId]);
        $isFavorite = true;
    }
}

// Отримання жанрів аніме
$stmt = $pdo->prepare("SELECT g.name FROM genres g 
                      JOIN anime_genres ag ON g.id = ag.genre_id 
                      WHERE ag.anime_id = ?");
$stmt->execute([$animeId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

require_once 'includes/header.php';
?>

<div class="container my-4">
    <div class="row">
        <div class="col-md-4">
            <img src="<?= htmlspecialchars($anime['poster']) ?>" 
     class="img-fluid rounded mb-3 anime-poster" 
     alt="<?= htmlspecialchars($anime['title']) ?>">
            
            <?php if (isLoggedIn()): ?>
                <form method="post" class="mb-3">
                    <button type="submit" name="toggle_favorite" class="btn btn-<?= $isFavorite ? 'danger' : 'success' ?> w-100">
                        <?= $isFavorite ? $translations['remove_from_favorites'] : $translations['add_to_favorites'] ?>
                    </button>
                </form>
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <h1><?= htmlspecialchars($anime['title']) ?></h1>
            <div class="mb-3">
                <span class="badge bg-secondary me-1"><?= htmlspecialchars($anime['year']) ?></span>
                <span class="badge bg-warning text-dark"><?= str_replace(':rating', htmlspecialchars($anime['rating']), $translations['rating']) ?></span>
            </div>
            <div class="mb-3">
                <?php foreach ($genres as $genre): ?>
                    <span class="badge bg-primary me-1"><?= htmlspecialchars($genre) ?></span>
                <?php endforeach; ?>
            </div>
            <h4><?= $translations['description'] ?></h4>
            <p class="lead"><?= htmlspecialchars($anime['description']) ?></p>
            
            <div class="mt-4">
                <h4><?= $translations['trailer'] ?></h4>
                <div class="ratio ratio-16x9">
                    <iframe src="<?= htmlspecialchars($anime['trailer']) ?>" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>