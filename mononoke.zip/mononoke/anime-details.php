<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/header.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$animeId = (int) $_GET['id'];

// Отримання інформації про аніме
$stmt = $pdo->prepare("SELECT * FROM anime WHERE id = ? LIMIT 1");
$stmt->execute([$animeId]);
$anime = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$anime) {
    header("Location: index.php");
    exit();
}

// Отримання жанрів аніме
$stmt = $pdo->prepare("SELECT g.name FROM genres g 
                      JOIN anime_genres ag ON g.id = ag.genre_id 
                      WHERE ag.anime_id = ?");
$stmt->execute([$animeId]);
$genres = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

// Перевірка чи аніме в улюблених
$isFavorite = false;
if (isLoggedIn()) {
    $stmt = $pdo->prepare("SELECT 1 FROM user_favorites WHERE user_id = ? AND anime_id = ?");
    $stmt->execute([$_SESSION['user_id'], $animeId]);
    $isFavorite = (bool) $stmt->fetch();
}

// Обробка додавання/видалення з улюблених
if (isLoggedIn() && isset($_POST['toggle_favorite'])) {
    if ($isFavorite) {
        $stmt = $pdo->prepare("DELETE FROM user_favorites WHERE user_id = ? AND anime_id = ?");
        $stmt->execute([$_SESSION['user_id'], $animeId]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO user_favorites (user_id, anime_id) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $animeId]);
    }
    header("Location: anime-details.php?id=$animeId");
    exit();
}
?>

<div class="container my-4">
    <div class="row">
        <div class="col-md-4">
            <img src="<?= htmlspecialchars($anime['poster']) ?>" class="img-fluid rounded mb-3" alt="<?= htmlspecialchars($anime['title']) ?>">
            
            <?php if (isLoggedIn()): ?>
                <form method="post" class="mb-3">
                    <button type="submit" name="toggle_favorite" class="btn btn-<?= $isFavorite ? 'danger' : 'success' ?> w-100">
                        <?= $isFavorite ? 'Видалити з улюблених' : 'Додати до улюблених' ?>
                    </button>
                </form>
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <h1><?= htmlspecialchars($anime['title']) ?></h1>
            <div class="mb-3">
                <span class="badge bg-secondary me-1"><?= htmlspecialchars($anime['year']) ?></span>
                <span class="badge bg-warning text-dark">Рейтинг: <?= htmlspecialchars($anime['rating']) ?>/10</span>
            </div>
            <div class="mb-3">
                <?php foreach ($genres as $genre): ?>
                    <span class="badge bg-primary me-1"><?= htmlspecialchars($genre) ?></span>
                <?php endforeach; ?>
            </div>
            <h4>Опис</h4>
            <p class="lead"><?= htmlspecialchars($anime['description']) ?></p>
            
            <div class="mt-4">
                <h4>Трейлер</h4>
                <div class="ratio ratio-16x9">
                    <iframe src="<?= htmlspecialchars($anime['trailer']) ?>" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>