<?php
require_once 'includes/config.php';

if (isset($_POST['lang']) && array_key_exists($_POST['lang'], $available_languages)) {
    $_SESSION['lang'] = $_POST['lang'];
    
    if (isLoggedIn()) {
        $stmt = $pdo->prepare("UPDATE user_settings SET language = ? WHERE user_id = ?");
        $stmt->execute([$_POST['lang'], $_SESSION['user_id']]);
    }
}

// Повертаємо на попередню сторінку
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit();
?>