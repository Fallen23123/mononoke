CREATE DATABASE IF NOT EXISTS anime_catalog;
USE anime_catalog;

-- Таблиця користувачів
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Таблиця аніме
CREATE TABLE anime (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    poster VARCHAR(255) NOT NULL,
    background VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    year INT NOT NULL,
    rating FLOAT NOT NULL,
    trailer VARCHAR(255) NOT NULL
);

-- Таблиця жанрів
CREATE TABLE genres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- Зв'язна таблиця для жанрів аніме
CREATE TABLE anime_genres (
    anime_id INT NOT NULL,
    genre_id INT NOT NULL,
    PRIMARY KEY (anime_id, genre_id),
    FOREIGN KEY (anime_id) REFERENCES anime(id) ON DELETE CASCADE,
    FOREIGN KEY (genre_id) REFERENCES genres(id) ON DELETE CASCADE
);

-- Додавання жанрів
INSERT INTO genres (name) VALUES 
('Боевик'), ('Приключения'), ('Комедия'), ('Драма'), ('Фэнтези'), 
('Ужасы'), ('Детектив'), ('Романтика'), ('Научная фантастика'), 
('Повседневность'), ('Спорт'), ('Триллер'), ('Мистика'), ('Сёдзё'), 
('Меха'), ('Исторический'), ('Сверхъестественное'), ('Путешествия во времени');

-- Додавання аніме (приклад для декількох записів)
INSERT INTO anime (title, poster, background, description, year, rating, trailer) VALUES 
('Атака титанов', 'https://th.bing.com/th/id/OIP.0mL26b1YWhreoHqokCfx1QHaEo?w=273&h=180&c=7&r=0&o=5&pid=1.7', 'https://th.bing.com/th/id/R.ffc18d1ddcef2f91a9b999c6d4dc09cd?rik=%2bRSHNE1QbLH%2bNA&riu=http%3a%2f%2fmultifandom.ru%2fpic%2f201509%2f1600x900%2fmultifandom.ru-1204.jpg&ehk=ug99C3gqCdSEowWXUFZu1RR7Q7h9rWLzvI1P88kNNrQ%3d&risl=&pid=ImgRaw&r=0', 'Загнанное в угол человечество доживает свои последние дни под гнётом титанов...', 2013, 8.5, 'https://www.youtube.com/embed/MGRm4IzK1SQ');

-- Додавання зв'язків аніме з жанрами
INSERT INTO anime_genres (anime_id, genre_id) VALUES 
(1, 1), (1, 4), (1, 5);