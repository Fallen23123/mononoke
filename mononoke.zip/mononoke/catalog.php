<?php require_once 'includes/config.php'; ?>
<?php require_once 'includes/header.php'; ?>

<div class="container">
    <h1 class="text-center my-4">Каталог аніме</h1>
    
    <div class="row">
        <div class="col-md-3">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Жанри</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="catalog.php" class="list-group-item list-group-item-action">Всі жанри</a>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM genres ORDER BY name");
                        while ($genre = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $active = (isset($_GET['genre']) && $_GET['genre'] == $genre['id']) ? 'active' : '';
                            echo "<a href='catalog.php?genre={$genre['id']}' class='list-group-item list-group-item-action $active'>{$genre['name']}</a>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Фільтри</h5>
                </div>
                <div class="card-body">
                    <form id="catalog-filters">
                        <div class="mb-3">
                            <label class="form-label">Рік випуску</label>
                            <select class="form-select" name="year">
                                <option value="">Всі роки</option>
                                <?php
                                $currentYear = date("Y");
                                for ($year = $currentYear; $year >= 2000; $year--) {
                                    $selected = (isset($_GET['year']) && $_GET['year'] == $year) ? 'selected' : '';
                                    echo "<option value='$year' $selected>$year</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Рейтинг</label>
                            <select class="form-select" name="rating">
                                <option value="">Будь-який</option>
                                <option value="9" <?= (isset($_GET['rating']) && $_GET['rating'] == 9) ? 'selected' : '' ?>>9+</option>
                                <option value="8" <?= (isset($_GET['rating']) && $_GET['rating'] == 8) ? 'selected' : '' ?>>8+</option>
                                <option value="7" <?= (isset($_GET['rating']) && $_GET['rating'] == 7) ? 'selected' : '' ?>>7+</option>
                                <option value="6" <?= (isset($_GET['rating']) && $_GET['rating'] == 6) ? 'selected' : '' ?>>6+</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Застосувати</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="anime-grid row" id="anime-grid">
                <?php
                $genreId = isset($_GET['genre']) ? (int)$_GET['genre'] : null;
                $year = isset($_GET['year']) ? (int)$_GET['year'] : null;
                $rating = isset($_GET['rating']) ? (float)$_GET['rating'] : null;
                
                $query = "SELECT a.* FROM anime a";
                $params = [];
                
                if ($genreId) {
                    $query .= " JOIN anime_genres ag ON a.id = ag.anime_id WHERE ag.genre_id = ?";
                    $params[] = $genreId;
                } else {
                    $query .= " WHERE 1=1";
                }
                
                if ($year) {
                    $query .= " AND a.year = ?";
                    $params[] = $year;
                }
                
                if ($rating) {
                    $query .= " AND a.rating >= ?";
                    $params[] = $rating;
                }
                
                $query .= " ORDER BY a.rating DESC";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute($params);
                
                while ($anime = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<div class="col-md-4 mb-4 anime-card">';
                    echo '  <div class="card h-100">';
                    echo '    <img src="' . htmlspecialchars($anime['poster']) . '" class="card-img-top" alt="' . htmlspecialchars($anime['title']) . '">';
                    echo '    <div class="card-body">';
                    echo '      <h5 class="card-title">' . htmlspecialchars($anime['title']) . '</h5>';
                    echo '      <div class="d-flex justify-content-between mb-2">';
                    echo '        <span class="text-muted">' . htmlspecialchars($anime['year']) . '</span>';
                    echo '        <span class="badge bg-warning text-dark">' . htmlspecialchars($anime['rating']) . '/10</span>';
                    echo '      </div>';
                    echo '      <p class="card-text">' . substr(htmlspecialchars($anime['description']), 0, 150) . '...</p>';
                    echo '    </div>';
                    echo '    <div class="card-footer bg-transparent">';
                    echo '      <a href="anime-details.php?id=' . $anime['id'] . '" class="btn btn-primary w-100">Детальніше</a>';
                    echo '    </div>';
                    echo '  </div>';
                    echo '</div>';
                }
                
                if ($stmt->rowCount() === 0) {
                    echo '<div class="col-12 text-center py-5">';
                    echo '  <h4>Аніме не знайдено</h4>';
                    echo '  <p>Спробуйте змінити параметри пошуку</p>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('catalog-filters').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const params = new URLSearchParams();
    
    for (const [key, value] of formData.entries()) {
        if (value) params.append(key, value);
    }
    
    const genreId = new URLSearchParams(window.location.search).get('genre');
    if (genreId) params.append('genre', genreId);
    
    window.location.href = 'catalog.php?' + params.toString();
});
</script>

<?php require_once 'includes/footer.php'; ?>