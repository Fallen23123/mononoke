<?php 
require_once 'includes/config.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Валідація
    if (empty($username)) {
        $errors[] = "Будь ласка, введіть ім'я користувача";
    } elseif (strlen($username) < 3) {
        $errors[] = "Ім'я користувача повинно містити принаймні 3 символи";
    }
    
    if (empty($email)) {
        $errors[] = "Будь ласка, введіть email";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Невірний формат email";
    }
    
    if (empty($password)) {
        $errors[] = "Будь ласка, введіть пароль";
    } elseif (strlen($password) < 6) {
        $errors[] = "Пароль повинен містити принаймні 6 символів";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Паролі не співпадають";
    }
    
    // Перевірка на унікальність імені користувача та email
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $errors[] = "Ім'я користувача або email вже використовуються";
        }
    }
    
    // Реєстрація
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $email, $hashed_password])) {
            $_SESSION['success_message'] = "Реєстрація успішна! Будь ласка, увійдіть.";
            redirect('login.php');
        } else {
            $errors[] = "Щось пішло не так. Спробуйте ще раз.";
        }
    }
}

require_once 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="text-center">Реєстрація</h3>
                </div>
                <div class="card-body">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error): ?>
                                <p class="mb-0"><?= htmlspecialchars($error) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Ім'я користувача</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?= htmlspecialchars($username) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?= htmlspecialchars($email) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Підтвердіть пароль</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Зареєструватися</button>
                    </form>
                    
                    <div class="mt-3 text-center">
                        <p>Вже маєте акаунт? <a href="login.php">Увійти</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>