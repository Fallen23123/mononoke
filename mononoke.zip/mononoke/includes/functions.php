<?php
require 'db.php';

// Реєстрація нового користувача
function registerUser($username, $email, $password) {
    global $db;
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    return $stmt->execute([$username, $email, $hashed]);
}

// Авторизація
function loginUser($email, $password) {
    global $db;
    
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        return true;
    }
    return false;
}

// Отримання аніме з БД
function getAnimeList() {
    global $db;
    $stmt = $db->query("SELECT * FROM anime ORDER BY title");
    return $stmt->fetchAll();
}