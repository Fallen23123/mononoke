<?php
require_once 'config.php';

$search = isset($_POST['search']) ? $_POST['search'] : '';
$genreId = isset($_POST['genre']) ? $_POST['genre'] : '';
$yearValue = isset($_POST['year']) ? $_POST['year'] : '';
$ratingValue = isset($_POST['rating']) ? $_POST['rating'] : '';

// Базовий запит
$query = "SELECT a.* FROM anime a";
$conditions = [];
$params = [];

// Додаємо умови
if (!empty($genreId)) {
    $query .= " JOIN anime_genres ag ON a.id = ag.anime_id WHERE ag.genre_id = ?";
    $conditions[] = $genreId;
} else {
    $query .= " WHERE 1=1";
}

if (!empty($search)) {
    $query .= " AND (a.title LIKE ? OR a.description LIKE ?)";
    $conditions[] = "%$search%";
    $conditions[] = "%$search%";
}

if (!empty($yearValue)) {
    if ($yearValue === 'older') {
        $query .= " AND a.year < 2012";
    } else {
        $query .= " AND a.year = ?";
        $conditions[] = $yearValue;
    }
}

if (!empty($ratingValue)) {
    $query .= " AND a.rating >= ?";
    $conditions[] = $ratingValue;
}

$query .= " ORDER BY a.rating DESC";

// Підготовка та виконання запиту
$stmt = $pdo->prepare($query);
$stmt->execute($conditions);

// Виведення результатів
while ($anime = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo '<div class="col-md-4 mb-4 anime-card">';
    echo '  <div class="card h-100">';
    echo '    <img src="' . htmlspecialchars($anime['poster']) . '" class="card-img-top" alt="' . htmlspecialchars($anime['title']) . '">';
    echo '    <div class="card-body">';
    echo '      <h5 class="card-title">' . htmlspecialchars($anime['title']) . '</h5>';
    echo '      <div class="d-flex justify-content-between mb-2">';
    echo '        <span class="text-muted">' . htmlspecialchars($anime['year']) . '</span>';
    echo '        <span class="badge bg-warning text-dark">' . htmlspecialchars($anime['rating']) . '/10</span>';
    echo '      </div>';
    echo '      <p class="card-text">' . substr(htmlspecialchars($anime['description']), 0, 150) . '...</p>';
    echo '    </div>';
    echo '    <div class="card-footer bg-transparent">';
    echo '      <a href="anime-details.php?id=' . $anime['id'] . '" class="btn btn-primary w-100">Детальніше</a>';
    echo '    </div>';
    echo '  </div>';
    echo '</div>';
}
?>