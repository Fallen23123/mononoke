$displayed = [];

while ($anime = $stmt->fetch(PDO::FETCH_ASSOC)) {
    if (in_array($anime['id'], $displayed)) {
        continue; // Пропускаємо повтор
    }
    $displayed[] = $anime['id']; // Додаємо до списку виведених

    echo '<div class="col-md-4 mb-4 anime-card">';
    echo '  <div class="card h-100">';
    echo '    <img src="' . htmlspecialchars($anime['poster']) . '" class="card-img-top" alt="' . htmlspecialchars($anime['title']) . '">';
    echo '    <div class="card-body">';
    echo '      <h5 class="card-title">' . htmlspecialchars($anime['title']) . '</h5>';
    echo '      <div class="d-flex justify-content-between mb-2">';
    echo '        <span class="text-muted">' . htmlspecialchars($anime['year']) . '</span>';
    echo '        <span class="badge bg-warning text-dark">' . htmlspecialchars($anime['rating']) . '/10</span>';
    echo '      </div>';
    echo '      <p class="card-text">' . substr(htmlspecialchars($anime['description']), 0, 150) . '...</p>';
    echo '    </div>';
    echo '    <div class="card-footer bg-transparent">';
    echo '      <a href="anime-details.php?id=' . $anime['id'] . '" class="btn btn-primary w-100">Детальніше</a>';
    echo '    </div>';
    echo '  </div>';
    echo '</div>';
}
