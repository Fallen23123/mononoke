<?php require_once 'includes/config.php'; ?>
<?php require_once 'includes/header.php'; ?>

<div class="container">
    <h1 class="text-center my-4">Популярні аніме</h1>
    
    <div class="search-container mb-4">
        <input type="text" id="search-input" class="form-control" placeholder="Пошук аніме...">
    </div>
    
    <div class="filters mb-4">
        <div class="row">
            <div class="col-md-4">
                <label for="genre-filter" class="form-label">Жанр</label>
                <select id="genre-filter" class="form-select">
                    <option value="">Всі жанри</option>
                    <?php
                    $stmt = $pdo->query("SELECT * FROM genres ORDER BY name");
                    while ($genre = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$genre['id']}'>{$genre['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="year-filter" class="form-label">Рік</label>
                <select id="year-filter" class="form-select">
                    <option value="">Всі роки</option>
                    <?php
                    $currentYear = date("Y");
                    for ($year = $currentYear; $year >= 2000; $year--) {
                        echo "<option value='$year'>$year</option>";
                    }
                    echo "<option value='older'>Раніше 2012</option>";
                    ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="rating-filter" class="form-label">Рейтинг</label>
                <select id="rating-filter" class="form-select">
                    <option value="">Будь-який</option>
                    <option value="9">9+</option>
                    <option value="8">8+</option>
                    <option value="7">7+</option>
                    <option value="6">6+</option>
                </select>
            </div>
        </div>
    </div>
    
    <div class="anime-grid row" id="anime-grid">
        <?php
        $stmt = $pdo->query("SELECT * FROM anime ORDER BY rating DESC LIMIT 12");
        while ($anime = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo '<div class="col-md-4 mb-4 anime-card">';
            echo '  <div class="card h-100">';
            echo '    <img src="' . htmlspecialchars($anime['poster']) . '" class="card-img-top" alt="' . htmlspecialchars($anime['title']) . '">';
            echo '    <div class="card-body">';
            echo '      <h5 class="card-title">' . htmlspecialchars($anime['title']) . '</h5>';
            echo '      <div class="d-flex justify-content-between mb-2">';
            echo '        <span class="text-muted">' . htmlspecialchars($anime['year']) . '</span>';
            echo '        <span class="badge bg-warning text-dark">' . htmlspecialchars($anime['rating']) . '/10</span>';
            echo '      </div>';
            echo '      <p class="card-text">' . substr(htmlspecialchars($anime['description']), 0, 150) . '...</p>';
            echo '    </div>';
            echo '    <div class="card-footer bg-transparent">';
            echo '      <a href="anime-details.php?id=' . $anime['id'] . '" class="btn btn-primary w-100">Детальніше</a>';
            echo '    </div>';
            echo '  </div>';
            echo '</div>';
        }
        ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const genreFilter = document.getElementById('genre-filter');
    const yearFilter = document.getElementById('year-filter');
    const ratingFilter = document.getElementById('rating-filter');
    
    function filterAnime() {
        const searchTerm = searchInput.value.toLowerCase();
        const genreId = genreFilter.value;
        const yearValue = yearFilter.value;
        const ratingValue = ratingFilter.value;
        
        fetch('includes/filter_anime.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `search=${encodeURIComponent(searchTerm)}&genre=${genreId}&year=${yearValue}&rating=${ratingValue}`
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById('anime-grid').innerHTML = data;
        });
    }
    
    searchInput.addEventListener('input', filterAnime);
    genreFilter.addEventListener('change', filterAnime);
    yearFilter.addEventListener('change', filterAnime);
    ratingFilter.addEventListener('change', filterAnime);
});
</script>

<?php require_once 'includes/footer.php'; ?>