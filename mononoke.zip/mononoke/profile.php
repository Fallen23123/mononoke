<?php 
require_once 'includes/config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$settings = getUserSettings($pdo, $user_id);

// Отримання улюблених аніме
$stmt = $pdo->prepare("SELECT a.* FROM anime a 
                      JOIN user_favorites uf ON a.id = uf.anime_id 
                      WHERE uf.user_id = ?
                      ORDER BY uf.added_at DESC");
$stmt->execute([$user_id]);
$favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once 'includes/header.php';
?>

<div class="container my-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4><?= $translations['account_settings'] ?></h4>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label"><?= $translations['username'] ?></label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($_SESSION['username']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?= $translations['language'] ?></label>
                        <select class="form-select" id="language-select">
                            <?php foreach ($available_languages as $code => $name): ?>
                                <option value="<?= $code ?>" <?= $code == $settings['language'] ? 'selected' : '' ?>><?= $name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4><?= $translations['favorites'] ?></h4>
                </div>
                <div class="card-body">
                    <?php if (count($favorites) > 0): ?>
                        <div class="row">
                            <?php foreach ($favorites as $anime): ?>
                                <div class="col-md-6 mb-3">
                                    <div class="card h-100">
                                        <div class="row g-0">
                                            <div class="col-md-4">
                                                <img src="<?= htmlspecialchars($anime['poster']) ?>" class="img-fluid rounded-start h-100" alt="<?= htmlspecialchars($anime['title']) ?>">
                                            </div>
                                            <div class="col-md-8">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?= htmlspecialchars($anime['title']) ?></h5>
                                                    <div class="d-flex justify-content-between mb-2">
                                                        <small class="text-muted"><?= str_replace(':year', htmlspecialchars($anime['year']), $translations['year']) ?></small>
                                                        <span class="badge bg-warning text-dark"><?= str_replace(':rating', htmlspecialchars($anime['rating']), $translations['rating']) ?></span>
                                                    </div>
                                                    <a href="anime-details.php?id=<?= $anime['id'] ?>" class="btn btn-sm btn-primary"><?= $translations['details'] ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <h5><?= $translations['no_favorites'] ?></h5>
                            <a href="catalog.php" class="btn btn-primary mt-3"><?= $translations['catalog'] ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('language-select').addEventListener('change', function() {
    window.location.href = '?lang=' + this.value;
});
</script>

<?php require_once 'includes/footer.php'; ?>